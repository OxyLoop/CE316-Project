public class Main {
    public static void main(String[] args) {
        System.out.println("Merhaba, " + (args.length > 0 ? args[0] : "Dünya"));
    }
}
